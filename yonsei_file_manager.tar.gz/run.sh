docker run -it -p 8080:8080 --name yonsei_file_manager --rm yonsei_file_manager
